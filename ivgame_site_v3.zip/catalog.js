(() => {
  const posts = Array.isArray(window.IVGAME_POSTS) ? window.IVGAME_POSTS : [];
  const grid = document.getElementById('articleGrid');
  if (!grid) return;
  const search = document.getElementById('searchInput');
  const pagination = document.getElementById('pagination');
  const empty = document.getElementById('emptyState');
  const title = document.getElementById('catalogTitle');
  const reset = document.getElementById('clearFilter');
  const perPage = 8;
  const categories = {all:'جدیدترین مطالب',subtitle:'زیرنویس فارسی',dub:'دوبله فارسی',trainer:'ترینر فارسی',mod:'مود بازی',news:'مقاله و اخبار روز'};
  const params = new URLSearchParams(location.search);
  let active = categories[params.get('category')] ? params.get('category') : 'all';
  let page = Math.max(1, parseInt(params.get('page') || '1', 10) || 1);
  const fa = n => new Intl.NumberFormat('fa-IR').format(n);
  const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const categoryNames = {subtitle:'زیرنویس فارسی',dub:'دوبله فارسی',trainer:'ترینر فارسی',mod:'مود بازی',news:'مقاله و اخبار روز'};
  function currentQuery(){ const value = search ? search.value : (params.get('q') || ''); return value.trim().toLocaleLowerCase('fa'); }
  function updateUrl(){
    const p = new URLSearchParams(); if(active !== 'all') p.set('category',active); if(page > 1) p.set('page',String(page)); if(currentQuery()) p.set('q',currentQuery());
    const next = location.pathname + (p.toString() ? '?' + p.toString() : '') + '#catalog';
    history.replaceState(null,'',next);
  }
  function render(){
    const q = currentQuery();
    const filtered = posts.filter(post => (active === 'all' || post.category === active) && (!q || `${post.title} ${post.game} ${post.description} ${categoryNames[post.category]}`.toLocaleLowerCase('fa').includes(q)));
    const pages = Math.max(1, Math.ceil(filtered.length / perPage));
    if(page > pages) page = pages;
    const slice = filtered.slice((page-1)*perPage, page*perPage);
    grid.innerHTML = slice.map(post => `
      <article class="article-card">
        <a class="card-image" href="${esc(post.url)}" aria-label="${esc(post.title)}">
          <img src="${esc(post.image)}" alt="${esc(post.game)}" loading="lazy" referrerpolicy="no-referrer">
          <span class="image-fallback">${esc(post.game)}</span>
        </a>
        <div class="card-body">
          <span class="category-tag">${esc(categoryNames[post.category])}</span>
          <h3><a href="${esc(post.url)}">${esc(post.title)}</a></h3>
          <p>${esc(post.description)}</p>
          <a class="read-more" href="${esc(post.url)}">ادامه مطلب <span aria-hidden="true">←</span></a>
        </div>
      </article>`).join('');
    grid.querySelectorAll('.card-image img').forEach(img => img.addEventListener('error', () => { const p=img.closest('.card-image'); p?.classList.add('failed'); img.remove(); }, {once:true}));
    if(title) title.textContent = categories[active] || categories.all;
    if(empty) empty.hidden = filtered.length !== 0;
    pagination.innerHTML = '';
    if(pages > 1){
      const prev=document.createElement('button'); prev.type='button'; prev.textContent='قبلی'; prev.disabled=page===1; prev.addEventListener('click',()=>go(page-1)); pagination.appendChild(prev);
      for(let p=1;p<=pages;p++){
        const b=document.createElement('button'); b.type='button'; b.textContent=fa(p); b.className=p===page?'active':''; b.setAttribute('aria-label',`صفحه ${p}`); b.setAttribute('aria-current',p===page?'page':'false'); b.addEventListener('click',()=>go(p)); pagination.appendChild(b);
      }
      const next=document.createElement('button'); next.type='button'; next.textContent='بعدی'; next.disabled=page===pages; next.addEventListener('click',()=>go(page+1)); pagination.appendChild(next);
    }
    document.querySelectorAll('[data-category]').forEach(a => a.classList.toggle('active', a.dataset.category===active));
    updateUrl();
  }
  function go(n){page=n;render();document.getElementById('catalog')?.scrollIntoView({behavior:'smooth',block:'start'});}
  document.querySelectorAll('[data-category]').forEach(a => a.addEventListener('click', e => {
    e.preventDefault(); active=a.dataset.category || 'all'; page=1; if(search) search.value=''; render();
  }));
  search?.addEventListener('input',()=>{page=1;render();});
  reset?.addEventListener('click',e=>{e.preventDefault();active='all';page=1;if(search)search.value='';render();});
  const initialQ=params.get('q'); if(search && initialQ) search.value=initialQ;
  window.addEventListener('popstate',()=>{const p=new URLSearchParams(location.search);active=categories[p.get('category')]?p.get('category'):'all';page=Math.max(1,parseInt(p.get('page')||'1',10)||1);if(search)search.value=p.get('q')||'';render();});
  render();
})();
