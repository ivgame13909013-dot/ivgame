(() => {
  const root = document.documentElement;
  const toggle = document.getElementById('themeToggle');
  const key = 'ivgame-theme';
  const readTheme = () => { try { return localStorage.getItem(key); } catch (_) { return null; } };
  const writeTheme = value => { try { localStorage.setItem(key, value); } catch (_) {} };
  const applyTheme = theme => {
    root.dataset.theme = theme;
    writeTheme(theme);
    if (toggle) {
      const dark = theme === 'dark';
      const icon = toggle.querySelector('.theme-icon');
      const label = toggle.querySelector('.theme-label');
      if (icon) icon.textContent = dark ? '☼' : '☾';
      if (label) label.textContent = dark ? 'تم سفید' : 'تم مشکی';
      toggle.setAttribute('aria-label', dark ? 'تغییر به تم سفید' : 'تغییر به تم مشکی');
    }
  };
  applyTheme(readTheme() === 'light' ? 'light' : 'dark');
  toggle?.addEventListener('click', () => applyTheme(root.dataset.theme === 'dark' ? 'light' : 'dark'));
  document.querySelectorAll('.cover-frame img,.card-image img').forEach(img => {
    img.addEventListener('error', () => {
      const parent = img.closest('.cover-frame,.card-image');
      if (parent) parent.classList.add('failed');
      img.remove();
    }, {once:true});
  });
  document.addEventListener('click', event => {
    const opened = document.querySelector('.software-menu[open]');
    if (opened && !opened.contains(event.target)) opened.removeAttribute('open');
  });
})();
